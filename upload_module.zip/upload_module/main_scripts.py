__author__ = 'liuzhen'

# main scripts

import compute_fisher
import search_similarity
import train_fisher_params

train_fisher_params
compute_fisher

search_similarity